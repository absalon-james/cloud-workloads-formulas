#!/bin/bash
for i in `seq 1 2000`;
do
    echo Fixing user $i
    drush user-password user$i --password="password$i"
done
