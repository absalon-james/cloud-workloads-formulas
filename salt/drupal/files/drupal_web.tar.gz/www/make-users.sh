#!/bin/bash
for i in `seq 1 2000`;
do
    echo Creating user $i
    drush user-create user$i --password password$i
done
